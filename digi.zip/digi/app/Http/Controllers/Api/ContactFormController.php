<?php

namespace App\Http\Controllers;
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Notification;
use App\Models\User;
use App\Notifications\contactForm;

class ContactFormController extends Controller
{
    public function sendMail(Request $request)
    {
        $details = [
            'greeting' => "Hi Admin",
            'fullname' => $request->fullname,
            'email' => $request->email,
            'phone' => $request->phone,
            'width' => $request->width,
            'height' => $request->height,
            'quantity' => $request->quantity,
            'about_us' => $request->about_us,
            'comments' => $request->comments,
        ];
        
        if($request->fabric != null)
            $details = array_merge($details, ['fullname' => $request->fullname]);
        if($request->email != null)
            $details = array_merge($details, ['email' => $request->email]);
        if($request->phone != null)
            $details = array_merge($details, ['phone' => $request->phone]);
        if($request->width != null)
            $details = array_merge($details, ['width' => $request->width]);
        if($request->height != null)
            $details = array_merge($details, ['height' => $request->fullnheightame]);
        if($request->quantity != null)
            $details = array_merge($details, ['quantity' => $request->quantity]);
        if($request->comments != null)
            $details = array_merge($details, ['comments' => $request->comments]);
        if($request->about_us != null)
            $details = array_merge($details, ['about_us' => $request->about_us]);

        Notification::send(User::first(), new contactForm($details));
    }
}
