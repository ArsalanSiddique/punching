<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class contactForm extends Notification
{
    use Queueable;
    public $order_id;

    private $details;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($details)
    {
        $this->details = $details;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        $details = [];
        
        if(isset($this->details['fullname']))
            $details = array_merge($details, ['fullname' => $this->details['fullname']]);
            
        if(isset($this->details['email']))
            $details = array_merge($details, ['email' => $this->details['email']]);

        if(isset($this->details['phone']))
            $details = array_merge($details, ['phone' => $this->details['phone']]);

        if(isset($this->details['width']))
            $details = array_merge($details, ['width' => $this->details['width']]);

        if(isset($this->details['height']))
            $details = array_merge($details, ['height' => $this->details['height']]);

        if(isset($this->details['about_us']))
            $details = array_merge($details, ['about_us' => $this->details['about_us']]);

        if(isset($this->details['comments']))
            $details = array_merge($details, ['comments' => $this->details['comments']]);
        
        dd($details);
        return (new MailMessage)
            ->error()
            ->subject('Contact Form Details')   
            ->greeting($this->details['greeting'])
            ->markdown('vendor.notifications.email', $this->details);
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            "response" => $this->details
        ];
    }
}
